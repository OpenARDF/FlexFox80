Version 0.7.10 - 25 Nov 2017
Hardware Compatibility: Rev X.1
Changes:
o Add the "A" command for setting receiver attenuation
o Improves filtering of RSSI when "SS" command is used
o Fixes a strange optimizer issue with the "BND" command by disabling
optimization for that command.